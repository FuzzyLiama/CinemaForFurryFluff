local SERVICE = {}

SERVICE.Name 			= "HTML"
SERVICE.IsTimed 		= true
SERVICE.Hidden 			= true

theater.RegisterService( 'html', SERVICE )